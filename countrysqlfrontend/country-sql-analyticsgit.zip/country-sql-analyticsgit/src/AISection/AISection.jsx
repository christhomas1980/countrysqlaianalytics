import React, { Component } from "react";
import Switch from "react-switch";
import SwitchAveTime from "./SwitchAveTime";

import WorkOrderMapping from "./WorkOrderMapping";




const AISection = () => {


    return (
        <div className="ai-section" >
        <SwitchAveTime></SwitchAveTime>
        <WorkOrderMapping></WorkOrderMapping>
        </div>
    );
};

export default AISection;
