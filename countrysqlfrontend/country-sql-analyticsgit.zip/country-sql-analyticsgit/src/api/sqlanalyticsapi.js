import axios from "axios";

let API_BASE_URL;

if (import.meta.env.MODE === "development") {
    API_BASE_URL = "https://sqlanalyticsapi20251228063713-hbdgcneufgambgdp.canadacentral-01.azurewebsites.net/api/v1/api/v1/";
} else {
    // PROD
    API_BASE_URL = "https://sqlanalyticsapi20251228063713-hbdgcneufgambgdp.canadacentral-01.azurewebsites.net/api/v1/api/v1/";
}

/* if (import.meta.env.MODE === "development") {
    API_BASE_URL = "https://localhost:7270/api/v1/api/v1/";
} else {
    // PROD
    API_BASE_URL = "https://localhost:7270/api/v1/api/v1/";
} */


// Replace above url with url below for test environment
// Example URL
// https://tcnparcgis.mycenterpointenergy.com/CNP.GIS.LatLongServices/ProcessLatLongScoreAddType?workType=Gas&jurisdiction=Houston&streetNumber=1111&streetName=louisiana&streetSuffix=St&city=Houston&state=Texas

const buildQueryString = (params) =>
    new URLSearchParams(Object.entries(params).filter(([, value]) => value !== undefined && value !== null && value !== "")).toString();

const fetchData = (params1, path) => {
 ///const queryString = buildQueryString(params);
    const url = `${API_BASE_URL}${path}`+'?question='+params1;

    return axios
        .get(url, { timeout: 1800000} )
        .then((response) => response.data)
        .catch((error) => {
            return handleApiError(error);
        });
};

const handleApiError = (error) => {
    if (error.response) {
        console.error(`API Error: ${error.response.status} - ${error.response.data}`);
        return Promise.reject(new Error(error.response.data || "An error occurred with the API."));
    } else if (error.request) {
        console.error("No response received:", error.request);
        return Promise.reject(new Error("No response from the server. Please try again."));
    } else {
        console.error("Request setup error:", error.message);
        return Promise.reject(new Error(error.message));
    }
};

const fetchSQLData = (params1, path) => {
    return fetchData(params1, path);
};


const SqlAnalyticsGetData= {
    getInformation: (params1) => {
        return fetchSQLData(params1,"getsqlquery");
    },


};

export default SqlAnalyticsGetData;
