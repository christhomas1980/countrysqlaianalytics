
import React, { useRef, useState, useEffect, useCallback } from "react";
import "./BottomResizableGrid.css";
import ChatBotGrid from "./ChatBotGrid";

const DEFAULT_GRID_HEIGHT = 300;
const MIN_GRID_HEIGHT = 120;
const MAX_GRID_HEIGHT = 480;

const BottomResizableGrid = ({ onHeightChange, query, querySeq }) => {
  const [height, setHeight] = useState(() => {
    const saved = Number(localStorage.getItem("bottomGridHeight"));
    if (Number.isFinite(saved)) {
      return Math.max(saved, MIN_GRID_HEIGHT); // clamp to minimum
    }
    return DEFAULT_GRID_HEIGHT;
  });

  useEffect(() => {
    onHeightChange?.(height);
    localStorage.setItem("bottomGridHeight", String(height));
  }, [height, onHeightChange]);

  const panelRef = useRef(null);
  const isDraggingRef = useRef(false);
  const startYRef = useRef(0);
  const startHeightRef = useRef(height);

  const onMouseDown = (e) => {
    isDraggingRef.current = true;
    startYRef.current = e.clientY;
    startHeightRef.current = height;
    document.body.style.cursor = "ns-resize";
    document.body.style.userSelect = "none";
  };

  const onMouseMove = useCallback((e) => {
    if (!isDraggingRef.current) return;
    const dy = startYRef.current - e.clientY; // up increases height
    const next = Math.min(
      MAX_GRID_HEIGHT,
      Math.max(MIN_GRID_HEIGHT, startHeightRef.current + dy)
    );
    setHeight(next);
  }, []);

  const onMouseUp = useCallback(() => {
    if (!isDraggingRef.current) return;
    isDraggingRef.current = false;
    document.body.style.cursor = "";
    document.body.style.userSelect = "";
  }, []);

  useEffect(() => {
    window.addEventListener("mousemove", onMouseMove);
    window.addEventListener("mouseup", onMouseUp);
    return () => {
      window.removeEventListener("mousemove", onMouseMove);
      window.removeEventListener("mouseup", onMouseUp);
    };
  }, [onMouseMove, onMouseUp]);

  return (
    <div
      ref={panelRef}
      className="bottom-grid"
      style={{ height, overflow: "auto" }}
    >
      <div
        className="bottom-grid__resizer"
        onMouseDown={onMouseDown}
        title="Drag to resize"
      />
      {/* Pass query + querySeq to trigger fetches */}
      <ChatBotGrid query={query} querySeq={querySeq} />
    </div>
  );
};

export default BottomResizableGrid;
