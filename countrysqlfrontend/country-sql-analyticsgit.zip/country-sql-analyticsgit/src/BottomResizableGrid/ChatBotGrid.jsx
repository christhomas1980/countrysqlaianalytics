
import React, { useEffect, useState, useCallback, useMemo } from "react";
import { DataGrid } from '@mui/x-data-grid';
import Box from '@mui/material/Box';
import SQLChatData from "../api/sqlanalyticsapi";


const ChatBotGrid = ({ query, querySeq }) => {
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const getSQLData = useCallback(async () => {
    if (!query || !query.trim()) return;

    try {
      setLoading(true);
      setError(null);

      const results = await SQLChatData.getInformation(query);
     

      // Normalize to array
      const arr = Array.isArray(results) ? results : [];

      // Ensure each row has an id (DataGrid requirement)
      const mapped = arr.map((item, idx) => ({
        id: item.id ?? item.ID ?? item.guid ?? `${idx + 1}`,
        ...item, // spread to keep all fields for dynamic columns
      }));

      setRows(mapped);
    } catch (err) {
      console.error(err);
      setError(
        err?.message === "The address you entered was not found within our service area."
          ? "Address not found in service area."
          : "Unable to load data. Try again."
      );
    } finally {
      setLoading(false);
    }
  }, [query]);

  useEffect(() => {
    getSQLData();
  }, [getSQLData, querySeq]);

  // ⚙️ Generate columns from the first row
  const columns = useMemo(() => {
    if (!rows.length) {
      // Show a tiny placeholder set (optional)
      return [
        { field: 'id', headerName: 'ID', width: 100 },
      ];
    }

    const sample = rows[0];
    const keys = Object.keys(sample);

    return keys.map((key) => {
      // Skip very large nested objects/arrays
      const isPrimitive =
        sample[key] === null ||
        ['string', 'number', 'boolean'].includes(typeof sample[key]) ||
        sample[key] instanceof Date;

      // Basic date detection
      const isDateLike = (v) =>
        v instanceof Date ||
        (typeof v === 'string' && /\d{4}-\d{2}-\d{2}/.test(v));

      // Provide reasonable default widths/flex
      const base = {
        field: key,
        headerName: key.replace(/_/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase()),
        minWidth: 120,
        flex: 1,
      };

      if (key.toLowerCase() === 'id') {
        return { ...base, width: 120, flex: 0 };
      }

      if (isDateLike(sample[key])) {
        return {
          ...base,
          width: 180,
          flex: 0,
          valueGetter: (params) => {
            const v = params.value;
            const d = v instanceof Date ? v : (v ? new Date(v) : null);
            return d ? d.toLocaleString() : '—';
          },
        };
      }

      if (!isPrimitive) {
        // Stringify nested values for display
        return {
          ...base,
          valueGetter: (params) => {
            try {
              return params.value != null ? JSON.stringify(params.value) : '—';
            } catch {
              return '—';
            }
          },
        };
      }

      return base;
    });
  }, [rows]);

  return (
    <Box
      sx={{
        position: 'relative',
        height: 400,
        width: '100%',
        backgroundColor: '#fff',
        borderTop: '1px solid #e5e7eb',
      }}
    >
      <DataGrid
        rows={rows}
        columns={columns}
        getRowId={(row) => row.id}
        pageSizeOptions={[5, 10, 25]}
        initialState={{
          pagination: { paginationModel: { pageSize: 10, page: 0 } },
        }}
        loading={loading}
        disableRowSelectionOnClick
      />
      {error && (
        <Box sx={{ p: 1, color: 'error.main', fontSize: 12 }}>
          {error}
        </Box>
      )}
      {!loading && !error && rows.length === 0 && (
        <Box sx={{ p: 1, color: 'text.secondary', fontSize: 12 }}>
          No results.
        </Box>
      )}
    </Box>
  );
};

export default ChatBotGrid;
