
import React, { useState,useContext } from "react";

import "./Chatbot.css";


const Chatbot = ({ onSend }) => {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [collapsed, setCollapsed] = useState(false);

  const handleSend = () => {
    if (input.trim() === "") return;
    setMessages((prev) => [...prev, { text: input, sender: "user" }]);

    // send up to parent
    if (typeof onSend === "function") {
      onSend(input);
    }


    setInput("");
   // getSQLData();
  };
  


  return (
    <div className={`chatbot-container ${collapsed ? "collapsed" : ""}`}>
      {/* Header with collapse button only */}
      <div className="chatbot-header">
        <span>Chatbot</span>
        <button
          className="chatbot-collapse-btn"
          aria-expanded={!collapsed}
          onClick={() => setCollapsed((c) => !c)}
          title={collapsed ? "Open chat" : "Collapse chat"}
        >
          {collapsed ? "Open" : "Collapse"}
        </button>
      </div>

      {/* Show messages and input only when not collapsed */}
      {!collapsed && (
        <>
          <div className="chatbot-messages">
            {messages.map((msg, index) => (
              <div key={index} className={`message ${msg.sender}`}>
                {msg.text}
              </div>
            ))}
          </div>
          <div className="chatbot-input">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Type a message..."
              onKeyDown={(e) => {
                if (e.key === "Enter") handleSend();
              }}
            />
            <button onClick={handleSend}>Send</button>
          </div>
        </>
      )}
    </div>
  );
};

export default Chatbot;
