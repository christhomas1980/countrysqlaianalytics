
// FloatingChat.jsx
import React, { useState } from "react";
import Chatbot from "./Chatbot";
import "./Chatbot.css";

const FloatingChat = () => {
  const [open, setOpen] = useState(false);
  return (
    <>
      <button
        className="chatbot-toggle"
        aria-expanded={open}
        aria-controls="chatbot-panel"
        onClick={() => setOpen(o => !o)}
      >
        {open ? "×" : "Chat"}
      </button>

      {open && (
        <div id="chatbot-panel" className="chatbot-wrapper">
          <Chatbot />
        </div>
      )}
    </>
  );
};

export default FloatingChat;