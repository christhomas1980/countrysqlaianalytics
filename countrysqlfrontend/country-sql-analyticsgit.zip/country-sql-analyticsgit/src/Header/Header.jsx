import SQLLogo from "../kindpng.png";
import "./Header.css";

const Header = () => {
    return (
        <header className="header">
            <div className="logo">
              
                    <img id="logoHeader" src={SQLLogo} alt="SQL logo" />
              
            </div>
            <div className="site-info">
                <h1 className="site-name">SQL Country Analytics</h1>
                <p className="tagline">Your quick guide to finding car sales per country</p>
            </div>
        </header>
    );
};

export default Header;
