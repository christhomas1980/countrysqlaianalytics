import { useState } from 'react'
import Header from "../Header/Header";
import Chatbot from "../Chatbot/Chatbot";
import ArcGISMap from "../Map/ArcGISMap";
import BottomResizableGrid from "../BottomResizableGrid/BottomResizableGrid";
import CountryChatData from "../api/countryanalyticsapi";
import './App.css'
import "@arcgis/core/assets/esri/themes/light/main.css";

function App() {
  
 const [chatQuery, setChatQuery] = useState("Show me the highest price car for each region but keep all the columns"); 
  const [chatQueryCountry, setChatQueryCountry] = useState(""); 
 const [chatSeq, setChatSeq] = useState(0);     // last user input
  const handleChatSend = async (input) => {
    setChatQuery(input);
    setChatSeq((s) => s + 1);   // guarantees change

   const countryResult = await CountryChatData.getInformation(input);
    setChatQueryCountry(countryResult);
  };

  
  const handleBottomGridHeightChange = (height) => {
    // optional: adjust layout/map based on the bottom grid height
    // console.log("Bottom grid height:", height);
  };


  return (
      <div className="app">
        <Header />
        <ArcGISMap selectedCountry={chatQueryCountry}></ArcGISMap>
     <BottomResizableGrid query={chatQuery} querySeq={chatSeq} onHeightChange={handleBottomGridHeightChange}></BottomResizableGrid>
         {/* Pass the callback to Chatbot */}
        <Chatbot onSend={handleChatSend}></Chatbot>
         </div>
  )
}

export default App
