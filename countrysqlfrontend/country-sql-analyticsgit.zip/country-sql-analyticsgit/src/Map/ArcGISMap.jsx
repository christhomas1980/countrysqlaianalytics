
// src/components/ArcGisMap.jsx
import React, { useEffect, useRef } from "react";
import Map from "@arcgis/core/Map";
import MapView from "@arcgis/core/views/MapView";
import Home from "@arcgis/core/widgets/Home";
import FeatureLayer from "@arcgis/core/layers/FeatureLayer";
import Extent from "@arcgis/core/geometry/Extent";
import BasemapGallery from "@arcgis/core/widgets/BasemapGallery";
import Expand from "@arcgis/core/widgets/Expand";
import Basemap from "@arcgis/core/Basemap";
import LocalBasemapsSource from "@arcgis/core/widgets/BasemapGallery/support/LocalBasemapsSource";
import "@arcgis/core/assets/esri/themes/light/main.css";
import "./ArcGISMap.css";

const ArcGISMap = ({ selectedCountry }) => {
  const mapDiv = useRef(null);
  const viewRef = useRef(null);
  const countriesLayerRef = useRef(null);

  useEffect(() => {
    if (!mapDiv.current) return;

    
const source = new LocalBasemapsSource({
  basemaps: [
    Basemap.fromId("streets"),            // default
    Basemap.fromId("topo-vector"),
    Basemap.fromId("dark-gray-vector"),
    Basemap.fromId("osm"),
    Basemap.fromId("satellite"),
  ],
});




    // ✅ Make Streets the default basemap
    const map = new Map({
      basemap: "", // default basemap
    });


const extentGeometry = new Extent({
  xmin: -170,   // Western boundary (Alaska)
  ymin: 20,     // Southern boundary (southern US)
  xmax: -50,    // Eastern boundary (Atlantic coast)
  ymax: 83,     // Northern boundary (northern Canada)
  spatialReference: { wkid: 4326 }, // WGS84
});


    const view = new MapView({
      container: mapDiv.current,
      map,
      center: [-95.3698, 29.7604], // Houston
      zoom: 3,                     // start a bit closer; 1 is very far out
      constraints: {
       // minScale: 100000000,
        // geometry: extentGeometry,
        rotationEnabled: false,
      },
      ui: { components: ["zoom", "attribution"] },
    });

    view.ui.move("zoom", "top-right");

    // Home widget
    const home = new Home({ view });
    view.ui.add(home, "top-right");

    // BasemapGallery
 /*    const basemapGallery = new BasemapGallery({
      view,
    }); */

    

const basemapGallery = new BasemapGallery({ view, source });
basemapGallery.activeBasemap = Basemap.fromId("streets");

    // Put the gallery in an Expand (compact button)
    const bgExpand = new Expand({
      view,
      content: basemapGallery,
      expandIcon: "basemap",
      expandTooltip: "Basemaps",
    });
       view.ui.add(bgExpand, "top-right");


  
    viewRef.current = view;
    // Countries layer (fix field name in definitionExpression: "COUNTRY")
    const countriesLayer = new FeatureLayer({
      url:
        "https://services.arcgis.com/P3ePLMYs2RVChkJx/ArcGIS/rest/services/World_Continents/FeatureServer/0",
      title: "World Countries",
      outFields: ["*"],
      definitionExpression: "Continent in ('North America','Europe','South America','Africa','Asia')",
      popupTemplate: {
        title: "{Continent}",
        content: [
          {
            type: "fields",
            fieldInfos: [
              { fieldName: "Continent", label: "Continent" },

            ],
          },
        ],
      },
    });
    map.add(countriesLayer);
    countriesLayerRef.current = countriesLayer

    return () => {
      view.destroy();
      viewRef.current = null;
      countriesLayerRef.current = null;
    };
  }, []);

  
useEffect(() => {
    if (
      !selectedCountry ||
      !viewRef.current ||
      !countriesLayerRef.current
    ) {
      return;
    }

    const view = viewRef.current;
    const layer = countriesLayerRef.current;

    const zoomToCountry = async () => {
      const query = layer.createQuery();
      query.where = `Continent = '${selectedCountry}'`; // 🔴 adjust field name if needed
      query.returnGeometry = true;
      query.outSpatialReference = view.spatialReference;

      try {
        const { features } = await layer.queryFeatures(query);

        if (!features.length) return;

        const feature = features[0];
        const target =
          feature.geometry.extent ?? feature.geometry;

        await view.goTo(target.expand(0.4), {
          duration: 1200,
          easing: "ease-in-out",
        });
      } catch (err) {
        console.error("Zoom to country failed:", err);
      }
    };

    zoomToCountry();
  }, [selectedCountry]);


  return (
    <div
      ref={mapDiv}
      className="arcgis-map-container"
      aria-label="ArcGIS Map"
    />
  );
};



export default ArcGISMap;
