﻿using System;
using System.Collections.Generic;

namespace SqlAnalyticsAPI.Models;

public partial class CtRealEstateSale
{
    public int? SerialNumber { get; set; }

    public int? ListYear { get; set; }

    public DateOnly? DateRecorded { get; set; }

    public string? Town { get; set; }

    public string? Address { get; set; }

    public int? AssessedValue { get; set; }

    public decimal? SalesAmount { get; set; }

    public decimal? SalesRatio { get; set; }

    public string? PropertyType { get; set; }

    public string? ResidentialType { get; set; }
}
