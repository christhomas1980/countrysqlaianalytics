﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace SqlAnalyticsAPI.Models;

public partial class AppDbContext : DbContext
{
    public AppDbContext()
    {
    }

    public AppDbContext(DbContextOptions<AppDbContext> options)
        : base(options)
    {
    }

    public virtual DbSet<BmwcarSale> BmwcarSales { get; set; }

    public virtual DbSet<CtRealEstateSale> CtRealEstateSales { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<BmwcarSale>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("BMWCarSales");

           
            entity.Property(e => e.EngineSize)
                .HasColumnType("decimal(18, 0)")
                .HasColumnName("Engine_Size");
            entity.Property(e => e.FuelType)
                .HasMaxLength(255)
                .IsUnicode(false)
                .HasColumnName("Fuel_Type");
            entity.Property(e => e.MileageKm).HasColumnName("Mileage_KM");
            entity.Property(e => e.Model)
                .HasMaxLength(255)
                .IsUnicode(false);
            entity.Property(e => e.PriceUsd)
                .HasColumnType("decimal(18, 0)")
                .HasColumnName("Price_USD");
            entity.Property(e => e.Region)
                .HasMaxLength(255)
                .IsUnicode(false);
            entity.Property(e => e.SalesClassification)
                .HasMaxLength(255)
                .IsUnicode(false)
                .HasColumnName("Sales_Classification");
            entity.Property(e => e.SalesVolume).HasColumnName("Sales_Volume");
            entity.Property(e => e.Transmission)
                .HasMaxLength(255)
                .IsUnicode(false);

            entity.Property(e => e.Color)
               .HasMaxLength(255)
               .IsUnicode(false);
        });

        modelBuilder.Entity<CtRealEstateSale>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("CT_RealEstateSales");

            entity.Property(e => e.Address)
                .HasMaxLength(255)
                .IsUnicode(false);
            entity.Property(e => e.AssessedValue).HasColumnName("Assessed_Value");
            entity.Property(e => e.DateRecorded).HasColumnName("Date_recorded");
            entity.Property(e => e.ListYear).HasColumnName("List_Year");
            entity.Property(e => e.PropertyType)
                .HasMaxLength(255)
                .IsUnicode(false)
                .HasColumnName("Property_Type");
            entity.Property(e => e.ResidentialType)
                .HasMaxLength(255)
                .IsUnicode(false)
                .HasColumnName("Residential_Type");
            entity.Property(e => e.SalesAmount)
                .HasColumnType("decimal(18, 0)")
                .HasColumnName("Sales_Amount");
            entity.Property(e => e.SalesRatio)
                .HasColumnType("decimal(18, 0)")
                .HasColumnName("Sales_Ratio");
            entity.Property(e => e.SerialNumber).HasColumnName("Serial_Number");
            entity.Property(e => e.Town)
                .HasMaxLength(255)
                .IsUnicode(false);
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
