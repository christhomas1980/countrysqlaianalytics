﻿using System;
using System.Collections.Generic;

namespace SqlAnalyticsAPI.Models;

public partial class BmwcarSale
{
    public string? Model { get; set; }

    public int? Year { get; set; }

    public string? Region { get; set; }

    public string? Color { get; set; }

    public string? FuelType { get; set; }

    public string? Transmission { get; set; }

    public decimal? EngineSize { get; set; }

    public int? MileageKm { get; set; }

    public decimal? PriceUsd { get; set; }

    public int? SalesVolume { get; set; }

    public string? SalesClassification { get; set; }
}
