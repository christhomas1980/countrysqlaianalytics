﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using SqlAnalyticsAPI.Models;
using System.Data;
using System.Text;
using System.Text.Json;

namespace SqlAnalyticsAPI.Controllers
{
    [ApiController]
    [Route("api/v1/")]
    public class SQLAnalyticsController : Controller
    {
        private readonly AppDbContext _context;

        public SQLAnalyticsController(AppDbContext context)
        {
            _context = context;

        }




        [HttpGet("api/v1/getsqlquery")]
        public async Task<IActionResult> GetSqlQuery(string question)
        {

            try
            {
                var client = new HttpClient();
                // Add your endpoint key
                client.DefaultRequestHeaders.Add();

                var requestBody = question;

                var content = new StringContent(requestBody, Encoding.UTF8, "application/json");
                var response = await client.PostAsync("https://sqlanalyticsproj-vegsk.eastus.inference.ml.azure.com/score", content);
                var result = await response.Content.ReadAsStringAsync();

                using var doc = JsonDocument.Parse(result);
                string rawOutput = doc.RootElement.GetProperty("output").GetString();


                // Remove markdown formatting
                string sqlQuery = rawOutput
                    .Replace("```sql", "")
                    .Replace("```", "")
                    .Trim();

                // Define your connection string
                string connectionString = "Server=tcp:aisqlserverdbm.database.windows.net,1433;Initial Catalog=aisqlserverdb;User ID=aiuseradmin;Password=Ceetee23!;Encrypt=True;";
                var dt = new DataTable();
               
                var rowsToReturn = new List<Dictionary<string, object?>>();
                // Create a connection object
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    try
                    {
                        // Open the connection
                        connection.Open();
                        Console.WriteLine("Connection successful!");

                        // Example: Execute a simple query
                        string query = sqlQuery;
                        using(SqlCommand command = new SqlCommand(query, connection))
                        {


                            using var reader = command.ExecuteReader();

                            // Create a DataTable and load the reader

                            dt.Load(reader);


                            // Build a JSON-friendly list of row objects
                            var rows = new List<Dictionary<string, object?>>(dt.Rows.Count);
                            foreach (DataRow dr in dt.Rows)
                            {
                                var obj = new Dictionary<string, object?>(dt.Columns.Count, StringComparer.OrdinalIgnoreCase);
                                foreach (DataColumn col in dt.Columns)
                                {
                                    var value = dr.IsNull(col) ? null : dr[col];

                                    // Normalize tricky types if needed
                                    if (value is byte[] bytes) value = Convert.ToBase64String(bytes);
                                    else if (value is Guid g) value = g.ToString();

                                    obj[col.ColumnName] = value;
                                }
                                rows.Add(obj);
                            }



                            rowsToReturn = rows;
                            //using (SqlDataReader reader = command.ExecuteReader())
                            //{
                            //   // dt.Load(reader);

                            //    while (reader.Read())
                            //    {
                            //        Console.WriteLine(reader[0].ToString());
                            //    }
                            //}
                        }

                      
                    }
                    catch (SqlException ex)
                    {
                        Console.WriteLine("SQL Error: " + ex.Message);
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine("Error: " + ex.Message);
                    }
                }


                //// ✅ Validate query (only SELECT allowed)
                //if (!sqlQuery.TrimStart().StartsWith("SELECT", StringComparison.OrdinalIgnoreCase))
                //{
                //    return BadRequest("Only SELECT queries are allowed.");
                //}

                //try
                //{
                //    // ✅ Execute raw SQL safely
                //    var result2 = await _context.CtRealEstateSales
                //        .FromSqlRaw(sqlQuery)
                //        .ToListAsync();

                //    return Ok(result2);
                //}
                //catch (Exception ex)
                //{
                //    return StatusCode(500, $"Error executing query: {ex.Message}");
                //}


                return Ok(rowsToReturn);
            }

            catch (Exception ex)
            {

                return StatusCode(500, ex.Message);
            }
        }



        [HttpGet("api/v1/getdatafromrag")]
        public async Task<IActionResult> GetDataFromRag(string ragQuery)
        {
            string query = ragQuery;

             _context.BmwcarSales.FromSqlRaw(ragQuery).ToList();

             var output = new List<object>();
   

            return Ok(output);
        }
    }
}
